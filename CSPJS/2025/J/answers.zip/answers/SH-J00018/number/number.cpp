#include<bits/stdc++.h>
using namespace std;
string s;
int num[10]={0};
int main()
{
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	cin>>s;
	int l=s.length();
	for(int i=0;i<l;i++)
	{
		if(s[i]>='0'&&s[i]<='9')
		{
			num[s[i]-'0']++;
		}
	}
	for(int i=9;i>-1;i--)
	{
		for(int j=0;j<num[i];j++)
		{
			printf("%d",i);
		}
	}
	return 0;
} 
