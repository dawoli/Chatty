// By Melacau, contest: 2022年中国大学生程序设计竞赛女生专场, problem: (B) 翻新道路 II, Accepted
#include <bits/stdc++.h>
using namespace std;

using s64 = long long;
using vi = vector<int>;

const int N = 1e5 + 5;

int n, m, q, crt, dfs_clk, dfn[N], siz[N], fa[N], top[N], wson[N], val[N], rpos[N];
vi G[N]; s64 dep[N], ans;

set<int> s;

void init() {
    s.clear();
    ans = crt = dfs_clk = 0;
    fill(G, G + n + 1, vi{});
    fill(wson, wson + n + 1, 0);
}

void dfs(int u, int f = 0) {
    fa[u] = f;
    dep[u] = dep[f] + val[u];
    siz[u] = 1;
    for (int& v : G[u]) if (v != f) {
        dfs(v, u);
        siz[u] += siz[v];
        if (siz[v] > siz[wson[u]])
            wson[u] = v;
    }
}

void build(int u, int tp) {
    top[u] = tp;
    rpos[dfn[u] = ++dfs_clk] = u;
    if (wson[u]) build(wson[u], tp);
    for (int& v : G[u]) if (v != fa[u] && v != wson[u]) build(v, v);
}

int lca(int u, int v) {
    while (top[u] != top[v])
        dep[top[u]] > dep[top[v]] ? u = fa[top[u]] : v = fa[top[v]];
    return dep[u] < dep[v] ? u : v;
}

void ins(int u) {
    auto it = s.insert(dfn[u]).first;
    if (crt == 0) { ans += val[crt = u];  return; }
    auto itr = it; ++itr;
    if (it == s.begin()) {
        int lcar = lca(u, rpos[*itr]);
        ans += dep[u] - dep[lcar];
        int nrt = lca(lcar, crt);
        ans += dep[crt] - dep[nrt];
        ans += val[nrt] - val[crt];
        crt = nrt;
        return;
    }
    auto itl = it; --itl;
    if (itr == s.end()) {
        int lcal = lca(u, rpos[*itl]);
        ans += dep[u] - dep[lcal];
        int nrt = lca(lcal, crt);
        ans += dep[crt] - dep[nrt];
        ans += val[nrt] - val[crt];
        crt = nrt;
        return;
    }
    int lcal = lca(u, rpos[*itl]);
    int lcar = lca(u, rpos[*itr]);
    ans += dep[u] - max(dep[lcal], dep[lcar]);
}


void rmv(int u) {
    auto it = s.find(dfn[u]);
    auto itr = it; ++itr;
    if (it == s.begin()) {
        if (itr == s.end()) {
            ans -= val[u];
            crt = 0;
            s.erase(it);
            return;
        }
        int lcar = lca(u, rpos[*itr]);
        ans -= dep[u] - dep[lcar];
        int nrt = lca(rpos[*itr], rpos[*s.rbegin()]);
        ans -= dep[nrt] - dep[crt];
        ans += val[nrt] - val[crt];
        crt = nrt;
        s.erase(it);
        return;
    }
    auto itl = it; --itl;
    if (itr == s.end()) {
        int lcal = lca(u, rpos[*itl]);
        ans -= dep[u] - dep[lcal];
        int nrt = lca(rpos[*itl], rpos[*s.begin()]);
        ans -= dep[nrt] - dep[crt];
        ans += val[nrt] - val[crt];
        crt = nrt;
        s.erase(it);
        return;
    }
    int lcal = lca(u, rpos[*itl]);
    int lcar = lca(u, rpos[*itr]);
    ans -= dep[u] - max(dep[lcal], dep[lcar]);
    s.erase(it);
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr); cout.tie(nullptr);
    int T; cin >> T; while (T--) {
        cin >> n >> m >> q;
        init();
        for (int i = 1; i <= n; ++i) cin >> val[i];
        for (int i = 1; i < n; ++i) {
            int x, y;
            cin >> x >> y;
            G[x].emplace_back(y);
            G[y].emplace_back(x);
        }
        dfs(1);
        build(1, 1);
        for (int i = 0, x; i < m; ++i) { cin >> x;  ins(x); }
        while (q--) {
            int op, x; cin >> op >> x;
            if (op == 2) rmv(x);
            else ins(x);
            cout << ans << '\n';
        }
    }
}