//src: By ix35, contest: The 2021 CCPC Guilin Onsite (XXII Open Cup, Grand Prix of EDG), problem: (E) Buy and Delete, Accepted
#include <bits/stdc++.h>
using namespace std;
const int MAXN=2010;
int n,m,c,x,y,z,mn,zxh,dis[MAXN],vis[MAXN];
vector < pair<int,int> > v[MAXN];
void solve (int x) {
	priority_queue < pair<int,int> > q;
	memset(dis,0x3f,sizeof(dis));
	memset(vis,0,sizeof(vis));
	dis[x]=0;
	q.push(make_pair(0,x));
	while (q.size()) {
		pair<int,int> a=q.top();
		q.pop();
		if (vis[a.second]) {continue;}
		vis[a.second]=1;
		int len=v[a.second].size();
		for (int i=0;i<len;i++) {
			if (v[a.second][i].first==x) {zxh=min(zxh,dis[a.second]+v[a.second][i].second);}
			if (dis[v[a.second][i].first]>dis[a.second]+v[a.second][i].second) {
				dis[v[a.second][i].first]=dis[a.second]+v[a.second][i].second;
				q.push(make_pair(-dis[v[a.second][i].first],v[a.second][i].first));
			}
		}
	}
}
int main () {
	scanf("%d%d%d",&n,&m,&c);
	mn=zxh=c+1;
	for (int i=1;i<=m;i++) {
		scanf("%d%d%d",&x,&y,&z);
		mn=min(mn,z);
		v[x].push_back(make_pair(y,z));
	}
	for (int i=1;i<=n;i++) {solve(i);}
	if (c<mn) {printf("0\n");}
	else if (c<zxh) {printf("1\n");}
	else {printf("2\n");}
	return 0;
}