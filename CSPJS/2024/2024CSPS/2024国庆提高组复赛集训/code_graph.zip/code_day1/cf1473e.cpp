// src: By LittleXi, contest: Educational Codeforces Round 102 (Rated for Div. 2), problem: (E) Minimum Path, Accepted
#include<iostream>
#include<array>
#include<queue>
#include<bits/stdc++.h>


using namespace std;

#define ll long long

ll n , m ;
vector<vector<array<ll,2>>> adj;

void link(ll l,ll r,ll w){
    // cout<<l<<" "<<r<<" "<<w<<endl;
    adj[l].push_back({r,w});
}
void dlink(ll l,ll r,ll w){
    // cout<<l<<" "<<r<<" "<<w<<endl;
    adj[l].push_back({r,w});
    adj[r].push_back({l,w});
}
vector<ll> dij(){
    priority_queue<pair<ll,ll>,vector<pair<ll,ll>>,greater<pair<ll,ll>>> pq;
    vector<ll> vis(4*n,0);
    pq.push({0,0});
    vector<ll> dis(4*n,2e18);dis[0] =0;
    while(pq.size()){
        if(vis[pq.top().second]){pq.pop();continue;}
        auto [w,x] = pq.top();pq.pop();
        vis[x] = 1;dis[x] = w;
        for(auto [tox , dw] :adj[x]){
            // cout<<x<<" "<<tox<<endl;
            if(vis[tox]) continue;
            if(w + dw > dis[tox]) continue;
            dis[tox] = w + dw;
            pq.push({w + dw , tox});
        }
    }  
    return dis;
}

void solve(){
    cin>>n>>m;
    adj = vector<vector<array<ll,2>>>(4*n);
    for(ll i =0;i<m;i++){
        ll l,r,w;cin>>l>>r>>w;l--;r--;
        dlink(l,r,w);dlink(n+l,n+r,w);dlink(2*n+l,2*n+r,w);dlink(3*n+l,3*n+r,w);
        link(l,n+r,2*w);link(r,n+l,2*w);
        link(2*n + l ,3*n+ r ,2 * w);link(2*n + r ,3*n+ l ,2 * w);
        link(l,2*n+r,0);link(r,2*n+l,0);
        link(n+l,3*n+r,0);link(n+r,3*n+l,0);
        link(l,3*n+r,w);link(r,3*n+l,w);
    }
    auto dis = dij();
    for(ll i = 3*n+1;i<4*n;i++){
        cout<<dis[i]<<" ";
    }
}

signed main(){
    solve();
}