// src: George_Plover
#include <cstdio>
#include <cstring>
#include <iostream>
#include <algorithm>
#include <vector>
#include <queue>

#define MAXN 210000
#define MAXM 510000
#define vint vector<int>
using namespace std;

int n,m;
int p[MAXN];
int top_order_required[MAXN];
vint pre[MAXN],suc[MAXN];
int outdeg[MAXN];
int color[MAXN];
priority_queue<pair<int,int> > q;

void init(){
    for(int i=1;i<=n;i++){
        top_order_required[i] = 0;
        pre[i].clear();
        suc[i].clear();
        outdeg[i] = 0;
        color[i] = 0;
    }
    while(!q.empty())q.pop();
}

void dfs(int u,int c){
    color[u] = c;
    for(auto v:suc[u]){
        if(!color[v]){
            dfs(v,c);
        }
    }
}

void remove_node(int u){
    for(auto v:pre[u]){
        outdeg[v]--;
        if(outdeg[v]==0 && !p[v]){
            q.push(make_pair(-color[v],v));
        }
    }
}

void solve(){
    scanf("%d%d",&n,&m);
    init();
    int fixed_elements = 0;
    for(int i=1;i<=n;i++){
        scanf("%d",&p[i]);
        if(p[i]!=0){
            top_order_required[p[i]] = i;
            fixed_elements++;
        }
    }
    for(int i=1;i<=m;i++){
        int u,v;
        scanf("%d%d",&u,&v);
        pre[u].push_back(v);
        suc[v].push_back(u);
        outdeg[v]++;
    }
    for(int i=1;i<=n;i++){
        if(top_order_required[i]!=0){
            int u = top_order_required[i];
            dfs(u,i);
        }
    }
    for(int i=1;i<=n;i++){
        if(color[i]==0){
            color[i] = n+1;
        }
    }
    for(int i=1;i<=n;i++){
        if(!outdeg[i] && !p[i]){
            q.push(make_pair(-color[i],i));
        }
    }
    int order = 0;
    while(!q.empty() || fixed_elements>0){
        if(top_order_required[order+1]!=0){
            int  u = top_order_required[order+1];
            order++;
            if(outdeg[u]!=0){
                puts("-1");return;
            }
            remove_node(u);
            fixed_elements--;
        }
        else if(!q.empty()){
            int u = q.top().second;
            p[u] = ++order;
            q.pop();
            remove_node(u);
        }
        else{
            puts("-1");return;
        }
    }
    for(int i=1;i<=n;i++){
        printf("%d%c",p[i],i==n?'\n':' ');
    }
}

int main(){

    int T;
    scanf("%d",&T);
    while(T--){
        solve();
    }
    return 0;
}