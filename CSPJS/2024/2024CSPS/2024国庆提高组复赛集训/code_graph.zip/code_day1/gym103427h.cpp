// By MagicalFlower, contest: The 2021 ICPC Asia Shenyang Regional Contest, problem: (H) Line Graph Matching, Accepted
#include<bits/stdc++.h>
using namespace std;
const int MAXN=100005;
const int MAXM=200005;
const int INF=0x3f3f3f3f;
vector<tuple<int,int,int>> e[MAXN];
int u[MAXM],v[MAXM],w[MAXM];
int low[MAXN],dfn[MAXN],tot;
int num[MAXN],cut[MAXM];
void dfs(int u,int fa)
{
    dfn[u]=low[u]=++tot;
    for(auto& [v,w,id]:e[u])
    {
        if(v==fa)continue;
        num[u]+=(dfn[u]>dfn[v]);
        if(!dfn[v])
        {
            dfs(v,u);
            num[u]+=num[v];
            if(low[v]>dfn[u])cut[id]=1;
            low[u]=min(low[u],low[v]);
        }
        else low[u]=min(low[u],dfn[v]);
    }
}
int main()
{
    int n,m;
    scanf("%d%d",&n,&m);
    long long res=0;
    for(int i=1;i<=m;i++)
    {
        scanf("%d%d%d",&u[i],&v[i],&w[i]);
        e[u[i]].emplace_back(v[i],w[i],i);
        e[v[i]].emplace_back(u[i],w[i],i);
        res+=w[i];
    }
    if(m%2==1)
    {
        dfs(1,0);
        int mi=INF;
        for(int i=1;i<=m;i++)
        {
            if(cut[i])
            {
                int sz=num[dfn[u[i]]>dfn[v[i]] ? u[i] : v[i]];
                if(sz%2==0)mi=min(mi,w[i]);
            }
            else mi=min(mi,w[i]);
        }
        res-=mi;
    }
    return 0*printf("%lld\n",res);
}
