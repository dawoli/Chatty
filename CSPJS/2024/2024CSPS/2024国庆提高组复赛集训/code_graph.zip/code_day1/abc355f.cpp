//src: George_Plover
#include <set>
#include <map>
#include <cmath>
#include <queue>
#include <cstdio>
#include <vector>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <algorithm>
#define MAXN 210000
#define MOD
#define LL long long 
#define PII pair<int,int>
#define X first
#define Y second
using namespace std;
int n,m;
struct DSU{
    int fa[MAXN],num;
    void init(){
        for(int i=1;i<=n;i++){
            fa[i]=i;
        }
        num=n;
    }
    int find(int x){
        return x==fa[x]?x:fa[x]=find(fa[x]);
    }
    void merge(int x,int y){
        x=find(x);y=find(y);
        if(x!=y){
            num--;
            fa[x]=y;
        }
    }
    int edges(){
        return n-num;
    }
}dsu[11];

int main(){
    cin>>n>>m;
    for(int i=1;i<=10;i++)dsu[i].init();
    for(int i=1;i<n;i++){
        int x,y,z;
        cin>>x>>y>>z;
        for(int j=z;j<=10;j++){
            dsu[j].merge(x,y);
        }
    }

    for(int i=1;i<=m;i++){
        int x,y,z;
        cin>>x>>y>>z;
        for(int j=z;j<=10;j++){
            dsu[j].merge(x,y);
        }
        int ans = 0;
        int last=0;
        for(int j=1;j<=10;j++){
            //cout<<dsu[j].edges()<<endl;
            ans+=(dsu[j].edges()-last)*j;
            last=dsu[j].edges();
        }
        cout<<ans<<endl;
    }

    return 0;
}