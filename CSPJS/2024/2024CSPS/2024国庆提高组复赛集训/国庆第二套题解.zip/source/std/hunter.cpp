#include <bits/stdc++.h>
using namespace std;
const int N=1e3+7,M=5e6+10;
int tt;
int n;
struct Point{
    int w;
    int x,y;
}p[N];
struct E{
    int sum,mn,mx;
    int id;
}e[M],e1[M],e2[M],e3[M];
bool cmp(E a,E b){
	if(a.mn==b.mn) return a.sum>b.sum;
    return a.mn>b.mn;   
}
bool cmp2(E a,E b){
	if(a.mx==b.mx) return a.sum>b.sum;
    return a.mx>b.mx;
}
bool cmp3(Point a,Point b){
    if(a.x==b.x)return a.y<b.y;
    return a.x<b.x;
}
void solve(){
    scanf("%d",&n);
    int x;
    int top=0;
    int ans=0;
    int mxxx=0,mxx=0;
    for(int i=1;i<=n;i++){
        for(int j=1;j<=n;j++){
            scanf("%d",&x);
            p[++top].w=x;
            p[top].x=i;
            p[top].y=j;
            if(x>mxxx){
                mxx=mxxx;
                mxxx=x;
            }
        }
    }
    ans=mxxx+mxx;//ɱһֻ����� 
    //cout<<ans<<endl;
    sort(p+1,p+1+top,cmp3);
    int cnt=0;
    for(int i=1;i<=top;i++){
        for(int j=i+1;j<=top;j++){
            for(int v=j+1;v<=top;v++){
                if(p[j].y>=p[i].y&&p[j].y<=p[v].y){ }
                else continue;
				++cnt;
                e[cnt].sum=e1[cnt].sum=p[i].w+p[j].w+p[v].w;
                e[cnt].mn=e1[cnt].mn=min(p[i].w,p[j].w);
                e[cnt].mn=e1[cnt].mn=min(e[cnt].mn,p[v].w);
                e[cnt].mx=e1[cnt].mx=max(p[i].w,p[j].w);
                e[cnt].mx=e1[cnt].mx=max(e[cnt].mx,p[v].w);
            }
        }
    }
	//ɱ��ֻ��·�� 
    int cnt2=0;
    for(int i=1;i<=top;i++){
        for(int j=i+1;j<=top;j++){
            if(p[j].y>=p[i].y){ }
            else continue;++cnt2;
            e2[cnt2].sum=e3[cnt2].sum=p[i].w+p[j].w;
            e2[cnt2].mn=e3[cnt2].mn=min(p[i].w,p[j].w);
            e2[cnt2].mx=e3[cnt2].mx=max(p[i].w,p[j].w);
        }
    }
	//ɱ��ֻ��·�� 
    sort(e+1,e+1+cnt,cmp);sort(e1+1,e1+1+cnt,cmp2);
    sort(e2+1,e2+1+cnt2,cmp);sort(e3+1,e3+1+cnt2,cmp2);
    int j=1;
    for(int i=1;i<=cnt;i++){
        while(e[i].mn<=e1[j].mx&&j<=cnt) j++;
        while(e[i].mn>e1[j].mx&&j<=cnt){ 
            ans=max(ans,e[i].sum+e1[j].sum);
            j++;
        }
    }
    //3+3
    j=1;
    for(int i=1;i<=cnt;i++){
        while(e[i].mn<=e3[j].mx&&j<=cnt) j++;
        while(e[i].mn>e3[j].mx&&j<=cnt){ 
            ans=max(ans,e[i].sum+e3[j].sum);
            j++;
        }
    }
    //3+2
    for(int k=1;k<=top;k++){
    	for(int i=1;i<=cnt;i++){
    		if(p[k].w<e[i].mn){
    			ans=max(ans,e[i].sum+p[k].w);
			}
		}		
	}
	//3+1
    j=1;
    int res=0;
    for(int i=1;i<=cnt2;i++){
        while(e2[i].mn<=e3[j].mx&&j<=cnt2) j++;
        while(e2[i].mn>e3[j].mx&&j<=cnt2){            
            ans=max(ans,e2[i].sum+e3[j].sum);
            j++;
        }
    }
	//2+2
    for(int k=1;k<=top;k++){
    	for(int i=1;i<=cnt2;i++){
    		if(p[k].w<e2[i].mn){
    			ans=max(ans,e2[i].sum+p[k].w);
			}
		}		
	}
	//2+1
    printf("%d",max(ans,e[1].sum));//3+0
}
signed main(){
	//freopen ("hunter.in","r",stdin);
	//freopen ("hunter.out","w",stdout);
    tt=1;
    while(tt--){
        solve();
        puts("");
    } 
    return 0;
}
/*
3
3 3 3
3 3 3
1 3 3
*/
