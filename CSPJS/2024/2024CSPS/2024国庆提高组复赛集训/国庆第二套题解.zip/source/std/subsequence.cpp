#include<bits/stdc++.h>

using namespace std;
typedef long long ll;

int a[50];
int n,m,mid;
set<int> st1,st2;

void dfs1(int t, ll summ)
{
	if(t==mid+1)
	{
		st1.insert(summ%m);
	}
	else
	{
		dfs1(t+1,summ);
		dfs1(t+1,(summ+a[t])%m);
	}
}

void dfs2(int t, ll summ)
{
	if(t==n+1)
	{
		st2.insert(summ%m);
	}
	else
	{
		dfs2(t+1,summ);
		dfs2(t+1,(summ+a[t])%m);
	}
}

int main()
{
//	freopen("subsequence.in","r",stdin);
//	freopen("subsequence.out","w",stdout);

	scanf("%d %d",&n,&m);
	if (n <= 0)
	{
		printf("0");
		return 0;
	}
	for(int i=1;i<=n;++i)
	{
		scanf("%d",&a[i]);
		a[i]%=m;
	}
	mid=n/2;
	dfs1(0,0);
	dfs2(mid+1,0);
	set<int>::iterator it,i;
	int ans=0;
	for(i=st1.begin();i!=st1.end();++i)
	{
		int goal=m-1-*i;
		it=st2.lower_bound(goal);
		if(*it!=goal) it--;
		ans=max(ans,(*it+ *i)%m);
	}
	printf("%d",ans);
	return 0;
}
