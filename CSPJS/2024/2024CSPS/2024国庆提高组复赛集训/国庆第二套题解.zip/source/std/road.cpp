#include<bits/stdc++.h>
using namespace std;

const int maxn=4e5+10;

vector<int> to[maxn];
int fat[maxn];
int st[maxn][32];
vector<int> query[maxn];

void dfs(int a,int fa){
	st[a][0]=fa;
	for(int j=1;j<32;j++){
		if(st[a][j-1]==0){
			st[a][j]=0;
		}
		else{
			st[a][j]=st[st[a][j-1]][j-1];
		}
	}
	for(int i=0;i<to[a].size();i++){
		int temp=to[a][i];
		if(temp==a){
			continue;
		}
		dfs(temp,a);
	}
	return;
}

int qr(int l,int r){
	int bushu=0;
	for(int j=31;j>=0;j--){
		if(st[l][j]>0&&st[l][j]<r){
			bushu+=1<<j;
			l=st[l][j];
		}
	}
	if(st[l][0]<r){
		return 0;
	}
	return bushu+1;
}

int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	int L,n,q;
	cin>>L>>n>>q;
	for(int i=1;i<=n;i++){
		int l,r;
		cin>>l>>r;
		query[l].push_back(r);
	}
	int maxa=0; 
	for(int i=1;i<=L;i++){
		for(int j=0;j<query[i].size();j++){
			int temp=query[i][j];
			maxa=max(maxa,temp);
		}
		fat[i]=maxa;
		to[maxa].push_back(i);
	}
	for(int i=1;i<=L;i++){
		if(fat[i]==i){
			dfs(i,0);
		}
	}
	for(int i=1;i<=q;i++){
		int l,r;
		cin>>l>>r;
		if(l==r){
			cout<<0<<'\n';
			continue;
		}
		int zhi= qr(l,r);
		if(zhi==0){
			cout<<-1<<'\n';
		}
		else{
			cout<<zhi<<'\n';
		}
	}
	return 0;
}
