#include <bits/stdc++.h>
using namespace std;
const int N=100005;
int nxt[26][N];
char s[N];
int main(){
	freopen ("password.in","r",stdin);
	freopen ("password.out","w",stdout);
	scanf ("%s",s+1);
	int n=strlen(s+1);
	for (int i=n;i>=1;i--){
		for (int j=0;j<26;j++)
			nxt[j][i]=nxt[j][i+1];
		nxt[s[i]-'a'][i]=i+1;
	}
	int ans=0;
	for (int a=0;a<26;a++)
		for (int b=0;b<26;b++)
			for (int c=0;c<26;c++)
				for (int d=0;d<26;d++){
					int x=nxt[a][1];
					bool flag=true;
					if (!x) flag=false;
					x=nxt[b][x];
					if (!x) flag=false;
					x=nxt[c][x];
					if (!x) flag=false;
					x=nxt[d][x];
					if (!x) flag=false;
					ans+=flag;
				}
	printf ("%d",ans);
	return 0;
}

