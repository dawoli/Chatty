//By George_Plover, contest: The 2022 ICPC Asia Xian Regional Contest, problem: (D) Contests, Accepted
#include <cstdio>
#include <cstring>
#include <iostream>
#include <algorithm>
#define MAXN 110000
using namespace std;

int n,m;
int p[5][MAXN];
int pos[MAXN][5];
int f[17][MAXN][5];
int minn[MAXN][5][5];

int main(){

    scanf("%d%d",&n,&m);
    for(int i=0;i<m;i++)
        for(int j=1;j<=n;j++){
            scanf("%d",&p[i][j]);
            pos[p[i][j]][i] = j;
        }

    for(int j=0;j<m;j++){
        for(int i=n;i>=1;i--){
            for(int k=0;k<m;k++){
                minn[i][j][k] = pos[p[j][i]][k];
                if(i<n)minn[i][j][k] = min(minn[i][j][k],minn[i+1][j][k]);
            }
        }
    }

    for(int i=1;i<=n;i++){
        for(int j=0;j<m;j++){
            f[0][i][j] = n+1;
            for(int k=0;k<m;k++){
                f[0][i][j]=min(f[0][i][j],minn[pos[i][k]][k][j]);
            }
        }
    }

    for(int k=1;k<17;k++){
        for(int i=1;i<=n;i++){
            for(int j=0;j<m;j++){
                f[k][i][j] = f[k-1][i][j];
                for(int l=0;l<m;l++){
                    f[k][i][j] = min(f[k][i][j],f[k-1][p[l][f[k-1][i][l]]][j]);
                }
            }
        }
    }

    int q;
    scanf("%d",&q);
    for(int i=1;i<=q;i++){
        int x,y;
        scanf("%d%d",&x,&y);
        bool flag=0;
        for(int j=0;j<m;j++){
            if(pos[x][j] < pos[y][j])flag=1;
        }
        if(flag){
            printf("%d\n",1);
            continue;
        }

        int a[5];
        int b[5];
        for(int j=0;j<m;j++)a[j]=x;
        int ans=0;
        for(int j=16;j>=0;j--){
            bool flag=0;
            for(int k=0;k<m;k++)b[k]=a[k];
            for(int k=0;k<m;k++){
                for(int l=0;l<m;l++){
                    if(f[j][a[k]][l] < pos[b[l]][l])b[l] = p[l][f[j][a[k]][l]];
                    if(f[j][a[k]][l] < pos[y][l]){
                        flag=1;
                        break;
                    }
                }
            }
            if(flag)continue;
            ans+=(1<<j);
            for(int k=0;k<m;k++){
                a[k]=b[k];
            }
        }
        ans+=2;
        printf("%d\n",ans>n?-1:ans);
    }
    //cout<<f[0][5][1]<<endl;


    return 0;
}