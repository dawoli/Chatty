//By pengpeng_fudan#, contest: 2022 China Collegiate Programming Contest (CCPC) Guilin Site, problem: (M) Youth Finale, Accepted,
#include <bits/stdc++.h>
#define ll long long
using namespace std;
const int N=6e6+5;
ll c[N];
ll n,m;
int a[N];
char s[N];
int shift,head,tail;
int lowbit(int n){
    return n&(-n);
}
void update(int pos){
    while(pos<=n){
       c[pos]+=1;
       pos+=lowbit(pos); 
    }
}
ll query(int pos){
    ll ans=0;
    while(pos){
        ans+=c[pos];
        pos-=lowbit(pos);
    }
    return ans;
}
void solve(){
    cin>>n>>m;
    shift=2e6;
    for(int i=1;i<=n;i++) cin>>a[shift+i];
    cin>>s;
    ll sum=0,tot=n*(n-1ll)/2ll;
    for(int i=n;i>=1;i--){
        sum+=query(a[shift+i]);
        update(a[shift+i]);
    }
    head=shift+1;
    tail=shift+n;
    cout<<sum<<endl;
    for(int i=0;i<m;i++){
        if(s[i]=='S'){
            if(head<=tail){
                sum=(sum-(a[head]-1)+(n-a[head]))%10;
                sum=(sum+10)%10;
                cout<<sum;
                a[++tail]=a[head];
                head++;
            }else{
                sum=(sum-(a[head]-1)+(n-a[head]))%10;
                sum=(sum+10)%10;
                cout<<sum;
                a[--tail]=a[head];
                head--;
            }
        }
        else{
            sum=(tot-sum)%10;
            sum=(sum+10)%10;
            cout<<sum;
            swap(head,tail);
        }
    }
    cout<<endl;
}
int main(){
    ios::sync_with_stdio(false),cin.tie(0);
    int _=1;
    // cin>>_;
    while(_--)  solve();
    return 0;
}