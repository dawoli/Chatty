//By Celestial_Intertwine: Kieray, George_Plover#, contest: The 2023 ICPC Asia Hong Kong Regional Programming Contest (The 1st Universal Cup, Stage 2:Hong Kong), problem: (E) Goose, Goose, DUCK?, Accepted
#include <cstdio>
#include <vector>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <algorithm>
#define MAXN 1100000
#define MOD
#define vint vector<int>
#define PII pair<int,int>
#define X first
#define Y second
#define LL long long
using namespace std;
int n,m,a[MAXN];
struct Segment_Tree{
    struct node{
        int l,r,tag,v;
    }tr[MAXN*4];

    int num;
    Segment_Tree(){
        num=1;
    }
    void pushup(int x,int L,int R){
        if(tr[x].tag)tr[x].v=R-L+1;
        else tr[x].v=tr[tr[x].l].v+tr[tr[x].r].v;
    }
    void Build(int x,int L,int R){
        if(L==R){
            tr[x].v=tr[x].tag=0;
            return;
        }
        int mid=(L+R)/2;
        tr[x].l=++num;
        Build(num,L,mid);
        tr[x].r=++num;
        Build(num,mid+1,R);
        pushup(x,L,R);
    }

    void Modify(int x,int L,int R,int al,int ar,int v){
        if(R<al||ar<L)return;
        if(al<=L&&R<=ar){
            tr[x].tag+=v;
            pushup(x,L,R);
            return;
        }
        int mid=(L+R)/2;
        Modify(tr[x].l,L,mid,al,ar,v);
        Modify(tr[x].r,mid+1,R,al,ar,v);
        pushup(x,L,R);
    }
}seg;
int loc[MAXN];
vint col[MAXN];
PII p[MAXN];

int main(){

    scanf("%d%d",&n,&m);
    seg.Build(1,1,n);

    for(int i=1;i<=n;i++){
        scanf("%d",&a[i]);
        col[a[i]].push_back(i);
    }

    for(int i=1;i<MAXN;i++){
        int u = col[i].size();
        for(int j=0;j<u;j++){
            if(j+m>u)p[col[i][j]]={-1,-1};
            else if(j+m==u)p[col[i][j]]={col[i][j+m-1],n};
            else p[col[i][j]]={col[i][j+m-1],col[i][j+m]-1};
        }
    }
    LL ans=0;
    for(int i=n;i>=1;i--){
        if(loc[a[i]]){
            auto t = p[loc[a[i]]];
            if(t.X!=-1)seg.Modify(1,1,n,t.X,t.Y,-1);
        }
        auto t = p[i];
        if(t.X!=-1)seg.Modify(1,1,n,t.X,t.Y,1);
        ans+=seg.tr[1].v;
        loc[a[i]]=i;
    }

    cout<<(1ll*n*(n+1)/2-ans)<<endl;



    return 0;
}