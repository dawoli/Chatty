//By Celestial_Intertwine: chenkehan, George_Plover#, contest: The 2022 ICPC Asia Xian Regional Contest, problem: (A) Bridge, Accepted
#include <map>
#include <cstdio>
#include <cstring>
#include <iostream>
#include <algorithm>
#define MAXN 410000
using namespace std;

int n,m,q;
int a[MAXN];
int Rt[MAXN];
map<int,int> R[MAXN];

struct FHQ_Treep{
    static const int Null = 0;
    int num,root;
    struct node{
        int l,r,fa;
        int rnd,val,siz;
        node(){siz=0;}
    }tr[MAXN*2];

    void init(){num=0;root=Null;}

    void pushup(int x){
        tr[x].siz=tr[tr[x].l].siz+tr[tr[x].r].siz+1;
        tr[tr[x].l].fa=tr[tr[x].r].fa=x;
    }
    inline int rnd(){return rand();}
    int add(int val){
        num++;tr[num].l=tr[num].r=Null;tr[num].rnd=rnd();
        tr[num].siz=1;tr[num].val=val;return num;
    }
    void split_val(int x,int k,int &l,int &r){
        if(!x){l=r=Null;return;}
        if(tr[x].val<=k){
            l=x;split_val(tr[x].r,k,tr[x].r,r);
        }
        else{
            r=x;split_val(tr[x].l,k,l,tr[x].l);
        }
        pushup(x);
    }
    int merge(int x,int y){
        if(!x||!y)return x|y;
        if(tr[x].rnd<tr[y].rnd){tr[x].r=merge(tr[x].r,y);pushup(x);return x;}
        else {tr[y].l=merge(x,tr[y].l);pushup(y);return y;}
    }

    int Lmost(int x){
        int ret=x;
        while(x){
            ret=x;
            x=tr[x].l;
        }
        return ret;
    }

    int Rmost(int x){
        int ret=x;
        while(x){
            ret=x;
            x=tr[x].r;
        }
        return ret;
    }

    void Set_root(int x){
        tr[x].fa=0;
    }

    int find_root(int x){
        while(tr[x].fa)x=tr[x].fa;
        return x;
    }

}treap;

int main(){
    //freopen("A.out","w",stdout);
    scanf("%d%d%d",&n,&m,&q);

    for(int i=1;i<=n;i++){
        Rt[i] = treap.add(0);
        treap.Set_root(Rt[i]);
        R[i][0] = i;
    }

    for(int i=1;i<=n;i++){
        Rt[i] = treap.merge(Rt[i],treap.add(m+1));
        treap.Set_root(Rt[i]);
        R[i][m+1] = i+n;
    }

    for(int i=1;i<=q;i++){
        int op,x,y;
        scanf("%d",&op);
        if(op==1){
            scanf("%d%d",&x,&y);
            auto l = --(R[x].upper_bound(y));
            auto r = --(R[x+1].upper_bound(y));
            int tA = treap.find_root(l->second);
            int tB = treap.find_root(r->second);

            int Al,Ar;
            int Bl,Br;
            //cout<<l->second<<" ";
            //cout<<treap.Lmost(tA)<<" "<<treap.Lmost(tB)<<endl;
            treap.split_val(tA,y,Al,Ar);
            treap.split_val(tB,y,Bl,Br);
            tA = treap.merge(treap.merge(Al,treap.add(y)),Br); R[x+1][y] = treap.num;
            tB = treap.merge(treap.merge(Bl,treap.add(y)),Ar); R[x][y] = treap.num;
            treap.Set_root(tA);
            treap.Set_root(tB);
        }
        else{
            scanf("%d",&x);
            printf("%d\n",treap.Rmost(treap.find_root(x))-n);
        }
    }





    return 0;
}