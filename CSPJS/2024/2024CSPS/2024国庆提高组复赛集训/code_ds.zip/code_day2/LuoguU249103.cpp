//George_Plover
#include <cstdio>
#include <cstring>
#include <iostream>
#include <algorithm>
#define MAXN 210000
#define LL long long
#define Base 19260817
#define MOD 100055128505716009ll
using namespace std;
 
inline LL mul(LL a,LL b){
    a%=MOD;b%=MOD;
    LL c = (long double) a*b/MOD;
    LL ans = a*b-c*MOD;
    if(ans<0)ans+=MOD;else if(ans>=MOD)ans-=MOD;
    return ans;
}
int n,m;
char s[MAXN];
int loc[26];
int nxt[MAXN][26];
int pre[MAXN];
LL h[MAXN],power[MAXN];
 
LL qpow(LL x,LL y){
    LL ret=1;
    while(y){
        if(y&1)
            ret=mul(ret,x);
        x=mul(x,x);
        y>>=1;
    }
    return ret;
}
 
int alpha_set(int L,int R){
    int ret=0;
    for(int i=0;i<26;i++){
        if(nxt[L][i]<=R)
            ret|=(1<<i);
    }
    return ret;
}
 
LL hashval(int L,int R){
    LL ret = (h[R]-mul(h[L-1],power[R-L+1])+MOD)%MOD;
    for(int i=0;i<26;i++){
        if(nxt[L][i]<=R){
            int x = nxt[L][i];
            ret = (ret - mul(pre[x],power[R-x]) + MOD)%MOD;
        }
    }
    return ret;
}
 
 
int main(){
     
    scanf("%s",s+1);
    n=strlen(s+1);
 
    power[0]=1;
    for(int i=1;i<=n;i++){
        power[i] = mul(power[i-1],Base);
    }
 
    for(int i=1;i<=n;i++){
        pre[i] = i-loc[s[i]-'a'];
        loc[s[i]-'a']=i;
    }
 
    for(int i=1;i<=n;i++){
        h[i] = (mul(h[i-1],Base)+pre[i])%MOD;
    }
 
    for(int i=0;i<26;i++)loc[i]=n+1;
    for(int i=n;i>=1;i--){
        loc[s[i]-'a']=i;
        for(int j=0;j<26;j++)
            nxt[i][j]=loc[j];
    }
 
 
    scanf("%d",&m);
    for(int i=1;i<=m;i++){
        int x,y,z,w;
        scanf("%d%d%d%d",&x,&y,&z,&w);
        if(y-x == w-z && alpha_set(x,y)==alpha_set(z,w) && hashval(x,y) == hashval(z,w)){
            puts("Yes");
        }
        else{
            puts("No");
        }
    }
 
    return 0;
}
