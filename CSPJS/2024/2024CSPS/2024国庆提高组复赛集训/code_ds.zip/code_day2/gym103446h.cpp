//By Gromah, contest: The 2021 ICPC Asia Shanghai Regional Programming Contest, problem: (H) Life is a Game, Accepted
#include <stdio.h>
#include <algorithm>
 
using namespace std;
 
struct edge {
	long long u , v , c;
} e[210000];
long long top;
long long n , m , q , tot;
long long a[220000];
long long c[210000] , rt[210000];
long long siz[220000] , nedv[220000] , nede[220000];
long long go[19][220000] , gon[19][220000];
bool cmp ( edge x1 , edge x2 ) {
	return x1.c < x2.c;
}
long long find ( long long x ) {
	long long i , t;
	for ( i = x ; c[i] > 0 ; i = c[i] ) ;
	while ( c[x] > 0 ) {
		t = c[x];
		c[x] = i;
		x = t;
	}
	return i;
}
void Union ( long long u , long long v , long long cost ) {
	tot++;
	nedv[tot] = cost;
	go[0][rt[u]] = tot;
	go[0][rt[v]] = tot;
	c[u] = v;
	rt[v] = tot;
}
void work () {
	long long i , j , u , x;
	scanf ( "%lld%lld%lld" , &n , &m , &q );
	for ( i = 1 ; i <= n ; i++ ) {
		scanf ( "%lld" , &a[i] );
		c[i] = -1; rt[i] = i;
	}
	for ( i = 1 ; i <= m ; i++ ) {
		scanf ( "%lld%lld%lld" , &e[i].u , &e[i].v , &e[i].c );
	}
	sort ( e + 1 , e + 1 + m , cmp );
	tot = n;
	for ( i = 1 ; i <= m ; i++ ) {
		if ( find(e[i].u) != find(e[i].v) ) {
			Union ( find(e[i].u) , find(e[i].v) , e[i].c );
		}
	}
	for ( i = 1 ; i <= n ; i++ ) {
		siz[i] = a[i];
		siz[go[0][i]] += a[i];
	}
	for ( i = n + 1 ; i <= tot ; i++ ) {
		siz[go[0][i]] += siz[i];
	}
	for ( i = 1 ; i <= tot ; i++ ) {
		nede[i] = nedv[go[0][i]] - siz[i];
		gon[0][i] = nede[i];
	}
	for ( i = 1 ; i <= 17 ; i++ ) {
		for ( j = 1 ; j <= tot ; j++ ) {
			go[i][j] = go[i-1][go[i-1][j]];
			gon[i][j] = max ( gon[i-1][j] , gon[i-1][go[i-1][j]] );
		}
	}
	for ( i = 1 ; i <= q ; i++ ) {
		scanf ( "%lld%lld" , &u , &x );
		for ( j = 17 ; j >= 0 ; j-- ) {
			if ( go[j][u] == 0 ) continue;
			if ( gon[j][u] <= x ) u = go[j][u];
		}
		printf ( "%lld\n" , x + siz[u] );
	}
}
int main () {
	work ();
	return 0;
}
 
