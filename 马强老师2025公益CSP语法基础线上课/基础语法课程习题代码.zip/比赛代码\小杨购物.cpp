/*
  
 */
#include<bits/stdc++.h>
using namespace std;
int main(){
	int a,b,n;
	cin>>n>>a>>b;
	cout<<n/(a+b);
	return 0;
}
