#include<iostream>
using namespace std;
int main(){
	char c;
	cin>>c;
	c=c-32;
	cout<<c<<endl;
	return 0;
}
