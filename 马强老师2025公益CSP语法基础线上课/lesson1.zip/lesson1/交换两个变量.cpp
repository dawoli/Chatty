#include<iostream>
using namespace std;
int main(){
	int a,b;
	cin>>a>>b;
	int c;
	c=a;
	a=b;
	b=c;
	cout<<a<<" "<<b<<endl;
	return 0;
}
